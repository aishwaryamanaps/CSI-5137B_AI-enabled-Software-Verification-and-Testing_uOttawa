package org.avmframework.examples.inputdatageneration;

import org.junit.Test;

public class TestTrace {

  @Test
  public void testNotEquals() {
    // TODO
  }
}
