package org.avmframework.localsearch;

class IntegerFibonacciNumberException extends RuntimeException {

  IntegerFibonacciNumberException(String message) {
    super(message);
  }
}
