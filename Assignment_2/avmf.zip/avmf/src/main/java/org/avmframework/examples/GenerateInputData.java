package org.avmframework.examples;

import org.apache.commons.math3.random.MersenneTwister;
import org.apache.commons.math3.random.RandomGenerator;
import org.avmframework.AlternatingVariableMethod;
import org.avmframework.Monitor;
import org.avmframework.TerminationPolicy;
import org.avmframework.Vector;
import org.avmframework.examples.inputdatageneration.Branch;
import org.avmframework.examples.inputdatageneration.TestObject;
import org.avmframework.examples.util.ArgsParser;
import org.avmframework.initialization.Initializer;
import org.avmframework.initialization.RandomInitializer;
import org.avmframework.localsearch.LocalSearch;
import org.avmframework.objective.ObjectiveFunction;

public class GenerateInputData {

  // HOW TO RUN:
  //
  // USAGE: java class org.avmframework.examples.GenerateInputData testobject branch [search]
  //   where:
  //     - testobject is a test object to generate data for (e.g., "Calendar", "Line" or "Triangle")
  //     - branch is a branch ID of the form X(T|F) where X is a branching node number (e.g., "5T")
  //     - [search] is an optional parameter denoting which search to use
  //       (e.g., "IteratedPatternSearch", "GeometricSearch" or "LatticeSearch")

  // CHANGE THE FOLLOWING CONSTANTS TO EXPLORE THEIR EFFECT ON THE SEARCH:
  // - search constants
  static final String SEARCH_NAME = "HillClimbingSearch"; // can also be set at the command line
  static final int MAX_EVALUATIONS = 100000;

  public static void main(String[] args) {
    // Nested class to help parse command line arguments
    GenerateInputDataArgsParser argsParser = new GenerateInputDataArgsParser(args); 
    //***Takes in the command line arguments 

    // instantiate the test object using command line parameters
    TestObject testObject = argsParser.parseTestObjectParam();
    //***Initiates a test object class for Calendar/Line/Triangle and returns in our case a new instance of Triangle() 
    
    // instantiate the branch using command line parameters
    Branch target = argsParser.parseBranchParam(testObject);
    //***Returns a branch object containing the target node(1/2/3/etc) and the target edge(T/F)
    
    // set up the local search, which can be overridden at the command line
    LocalSearch localSearch = argsParser.parseSearchParam(SEARCH_NAME);
    //***Returns an instantiation of one of the local search algorithm classes. We need to create our own for hill climbing in
    //***org.avmframework.localsearch
     
    // set up the objective function
    ObjectiveFunction objFun = testObject.getObjectiveFunction(target);
    //*** Returns TriangleBranchTargetObjectiveFunction instance which contains the dependencies and the control flow 
    
    // set up the vector
    Vector vector = testObject.getVector();
    //***In our triangle case, returns a vector containing the first 3 values 0,0,100
    
    // set up the termination policy
    TerminationPolicy terminationPolicy =
        TerminationPolicy.createMaxEvaluationsTerminationPolicy(MAX_EVALUATIONS);
    //***Returns a TerminationPolicy object {terminateOnOptimal:True, maxEvaluations:100000, maxRestarts:-1, runningTime:-1}

    // set up random initialization of vectors
    RandomGenerator randomGenerator = new MersenneTwister();
    Initializer initializer = new RandomInitializer(randomGenerator);
    //***Some Random number generator

    // set up the AlternatingVariableMethod
    AlternatingVariableMethod avm = new AlternatingVariableMethod(
        localSearch, terminationPolicy, initializer);
    //***Setting up of the AVM object 

    // perform the search
    Monitor monitor = avm.search(vector, objFun);
    //***Perform the search using the vector of inputs and the objective function specified

    // output the results
    System.out.println("Best solution: " + monitor.getBestVector());
    System.out.println("Best objective value: " + monitor.getBestObjVal());
    System.out.println(
        "Number of objective function evaluations: "
            + monitor.getNumEvaluations()
            + " (unique: "
            + monitor.getNumUniqueEvaluations()
            + ")");
    System.out.println("Running time: " + monitor.getRunningTime() + "ms");
  }

  static class GenerateInputDataArgsParser extends ArgsParser {
    static final int TEST_OBJECT_PARAM_INDEX = 0; //Calendar/Line/Triangle 
    static final int BRANCH_PARAM_INDEX = 1; //1T/1F/2T/2F and so on
    static final int SEARCH_PARAM_INDEX = 2; //Search algorithm
    static final int MIN_NUM_ARGS = 2;

    GenerateInputDataArgsParser(String[] args) {
      super(GenerateInputData.class, args);
    }

    protected void addParams() {
      addParam(
          "testobject",
          "a test object to generate data for (e.g., \"Calendar\", \"Line\" or \"Triangle\")");
      addParam(
          "branch",
          "a branch ID of the form X(T|F) where X is a branching node number (e.g., \"5T\")");
      super.addParams();
    }

    TestObject parseTestObjectParam() {
      TestObject testObject = null;
      if (args.length > TEST_OBJECT_PARAM_INDEX) {
        String testObjectName = args[TEST_OBJECT_PARAM_INDEX];

        try {
          testObject = TestObject.instantiate(testObjectName);
        } catch (Exception exception) {
          error(exception.getMessage());
        }

      } else {
        wrongNumberOfArgumentsError();
      }

      return testObject;
    }

    Branch parseBranchParam(TestObject testObject) {
      Branch branch = null;
      if (args.length > BRANCH_PARAM_INDEX) {
        String suppliedParam = args[BRANCH_PARAM_INDEX];

        try {
          branch = Branch.instantiate(suppliedParam, testObject); //**Creates a new branch with node number and edge taken
        } catch (Exception exception) {
          error(exception.getMessage());
        }
      } else {
        wrongNumberOfArgumentsError();
      }

      return branch;
    }

    public LocalSearch parseSearchParam(String defaultSearch) {
      return super.parseSearchParam(SEARCH_PARAM_INDEX, defaultSearch);
    }

    void wrongNumberOfArgumentsError() {
      error(
          "Wrong number of arguments -- expected at least " + MIN_NUM_ARGS + " got " + args.length);
    }
  }
}
