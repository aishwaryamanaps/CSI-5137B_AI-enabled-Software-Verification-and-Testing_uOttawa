package org.avmframework.examples.inputdatageneration;

public class DivergencePoint {

  public int traceIndex;
  public int chainIndex;

  public DivergencePoint(int traceIndex, int chainIndex) {
    this.traceIndex = traceIndex;
    this.chainIndex = chainIndex;
  }
}
